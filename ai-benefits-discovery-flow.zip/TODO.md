# PLUM Task Submission Checklist

## 1. Screen Recording Video
- [ ] Record a working demo of the project showing the complete user flow (input -> loading -> benefits list -> details).
- [ ] For web: Hosted demo or local screen recording.
- [ ] Ensure audio narration if needed, show all screens.

## 2. ZIP File of Source Code
- [ ] Create a ZIP file of the complete source code.
- [ ] Ensure README.md is included with:
  - [x] Prompts used and refinements made.
  - [x] Architecture explanation and state management choices (updated to Zustand).
  - [x] Screenshots of key screens (placeholders added).
  - [x] Known issues and potential improvements.

## 3. DOC File (Summary Document)
- [ ] Create a DOC file with the same details as README.md.
- [ ] Include:
  - [ ] Hosted interactive link (for web).
  - [ ] GitHub repository link.
  - [ ] Architecture explanation and state management choices.
  - [ ] Screenshots of key screens.
  - [ ] Known issues and potential improvements.

## 4. Drive Folder and File Naming
- [ ] Name the Drive folder: <Your_Name>_<Problem_Statement_Number> (e.g., John_Doe_3)
- [ ] Name the DOC file: <Your_Name>_<Problem_Statement_Number> (e.g., John_Doe_3.doc)

## Additional Steps
- [ ] Host the web app if possible (e.g., on Vercel, Netlify).
- [ ] Push code to GitHub and get repository link.
- [ ] Test the app locally before recording.
- [ ] Verify all files are included in ZIP.
